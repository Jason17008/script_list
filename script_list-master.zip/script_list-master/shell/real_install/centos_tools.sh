#!/bin/bash


yum install   bash-completion curl   vim  wget  httpd-tools  tree nmap  lrzsz nc lsof wget tcpdump atop htop iftop iotop t nethogs  psmisc net-tools stress sysstat vim-enhanced dos2unix  yum-utils device-mapper-persistent-data  lvm2 bcc-tools libbcc-examples linux-headers-$(uname -r) bcc-tools libbcc-examples linux-headers-$(uname -r) kernel-devel-$(uname -r) kernel-headers-$(uname -r)  -y  