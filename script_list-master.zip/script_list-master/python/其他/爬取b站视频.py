yum install python3-pip -y


pip3 install you-get



pip3 --default-timeout=100 install -U you-get


seq 60 | xargs -i -P3 you-get 
https://www.bilibili.com/video/BV1KX4y1S7dT?p={}


seq 是集  如何这集合 有100个  选100个  P3 是并发的下载几个  不能过3 会被封禁 
把合集里面的 ？ 前面的复制下来 即可 

https://www.bilibili.com/video/bv1umsfemexa/?spm from-333.999.0.08vd source-fef209e03f588bc1ebc902abc3999683  

复制?之前的 